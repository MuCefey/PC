package com.example.nkpc;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class CartActivity extends AppCompatActivity {
    private ListView listView;
    private ArrayList<Product> cartItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        listView = findViewById(R.id.cart_list_view);
        cartItems = (ArrayList<Product>) getIntent().getSerializableExtra("cartItems");

        displayCartItems();
    }
    public void addProductToCart(Product product) {
        cartItems.add(product); // Добавляем продукт в корзину
        Toast.makeText(this, product.getName() + " добавлен в корзину", Toast.LENGTH_SHORT).show(); // Уведомление
    }

    private void displayCartItems() {
        ArrayList<String> itemDetails = new ArrayList<>();
        for (Product product : cartItems) {
            itemDetails.add(product.getName() + " - " + product.getPrice() + "₽");
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.list_item, itemDetails) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView textView = view.findViewById(R.id.item_text);
                textView.setText(itemDetails.get(position));
                return view;
            }
        };
        listView.setAdapter(adapter);
    }
}
